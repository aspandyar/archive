const todoService = require("../repository/todoRepository");

exports.getAllTodos = async (req, res) => {
  try {
    const todos = await todoService.getAllTodos();
    res.json({ data: todos, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createTodo = async (req, res) => {
  try {
    const todo = await todoService.createTodo(req.body);
    res.json({ data: todo, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getTodoById = async (req, res) => {
  try {
    const todo = await todoService.getTodoById(req.params.id);
    res.json({ data: todo, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateTodo = async (req, res) => {
  try {
    const todo = await todoService.updateTodo(req.params.id, req.body);
    res.json({ data: todo, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteTodo = async (req, res) => {
  try {
    const todo = await todoService.deleteTodo(req.params.id);
    res.json({ data: todo, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};