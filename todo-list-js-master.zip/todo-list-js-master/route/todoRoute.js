const express = require("express");
const {getAllTodos, createTodo, getTodoById, updateTodo, deleteTodo} = require("../service/todoService");

const router = express.Router();

router.route("/").get(getAllTodos).post(createTodo);
router.route("/:id").get(getTodoById).put(updateTodo).delete(deleteTodo);

module.exports = router;