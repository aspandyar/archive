const todoModel = require("../models/Task");

exports.getAllTodos = async () => {
    return await todoModel.find();
};

exports.createTodo = async (todo) => {
    return await todoModel.create(todo);
};
exports.getTodoById = async (id) => {
    return await todoModel.findById(id);
};

exports.updateTodo = async (id, todo) => {
    return await todoModel.findByIdAndUpdate(id, todo);
};

exports.deleteTodo = async (id) => {
    return await todoModel.findByIdAndDelete(id);
};