# todo-list-js


## to start a mongodb:

```bash
    $ docker -v
```

if no docker **download** it

```bash
    $ docker-compose up -d
    $ docker exec -it todo-list-js_mongo_1 mongosh mongodb://root:secret@mongo:27017/
```


