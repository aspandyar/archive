## Email Sender Application

This Node.js application allows you to send emails using your Yandex email account. It utilizes the nodemailer library to handle email sending functionality.

### Prerequisites
- Node.js installed on your system.

### Installation
1. Clone or download the repository to your local machine.
2. Navigate to the project directory in your terminal.
3. Run the following command to install the required dependencies:

```bash
    npm install
```

### Configuration
1. Create a `.env` file in the project directory.
2. Add your Yandex email credentials to the `.env` file in the following format:

```makefile
    YANDEX_USER=your_yandex_email
    YANDEX_PASS=your_yandex_password
```

### Usage
1. Run the application using the following command, replacing `filename.js` with the name of your JavaScript file:

```bash
    node filename.js
```

2. Follow the prompts in the command line to enter the recipient email address, subject, and message body.
3. After providing the required information, the application will send the email using the specified Yandex SMTP service.

