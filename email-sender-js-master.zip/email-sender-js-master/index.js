// Import necessary modules
const nodemailer = require('nodemailer'); // Nodemailer for sending emails
const smtpTransport = require('nodemailer-smtp-transport'); // SMTP transport for Nodemailer
const readline = require('readline'); // Readline for user input

require('dotenv').config(); // Load environment variables

// Create readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Create email transporter
const transporter = nodemailer.createTransport(smtpTransport({
  service: 'yandex',
  auth: {
    user: process.env.YANDEX_USER,
    pass: process.env.YANDEX_PASS
  }
}));

// Prompt user for email details and send email
rl.question('Enter recipient email address: ', (recipient) => {
  rl.question('Enter email subject: ', (subject) => {
    rl.question('Enter message body (HTML content): ', (message) => {
      const mailOptions = {
        from: process.env.YANDEX_USER,
        to: recipient,
        subject: subject,
        html: message
      };

      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          console.log('Error occurred: ', error);
        } else {
          console.log('Email sent: ' + info.response);
        }
        rl.close();
      });
    });
  });
});

// Event listener for readline close event
rl.on('close', () => {
  console.log('Exiting...');
});
