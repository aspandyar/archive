# Weather App

An application that provides weather information based on user input. It utilizes the OpenWeatherMap API for weather data, the Time API for time information, and the FreeCurrConv API for currency conversion.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Usage](#usage)
- [Api Usage](#apis-used)
- [Contributing](#contributing)

## Prerequisites

Before you begin, ensure you have the following requirements:

- [Node.js](https://nodejs.org/) installed on your machine.
- [npm](https://www.npmjs.com/) (Node Package Manager) installed.

## Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/aspandyar/weather-app.git
   ```

2. Navigate to the project directory:

   ```bash
   cd weather-app
   ```

3. Install dependencies:

   ```bash
   npm install
   ```

## Usage

1. Start the server:

   ```bash
   npm start
   ```

2. Open your web browser and visit [http://localhost:3000](http://localhost:3000).

3. You should see the weather application up and running.

4. Enter a city in the provided input field and click "Get Weather" to fetch weather information.

## APIs Used

- **OpenWeatherMap API:**
  - Endpoint: `https://api.openweathermap.org/data/2.5/weather`
  - API Key Required: Yes
  - Obtain your API key from [OpenWeatherMap](https://openweathermap.org/api)

- **Time API:**
  - Endpoint: `https://timeapi.io/api/Time/current/coordinate`
  - API Key Required: No
  - More information at [Time API](https://timeapi.io/)

- **FreeCurrConv API:**
  - Endpoint: `https://free.currconv.com/api/v7/convert`
  - API Key Required: Yes
  - Obtain your API key from [FreeCurrConv API](https://www.currencyconverterapi.com/)

## Contributing

If you'd like to contribute, please follow these steps:

1. Fork the repository on GitHub.
2. Clone your fork locally.
3. Create a new branch with a descriptive name.

   ```bash
   git checkout -b feature/new-feature
   ```

4. Make your changes and commit them:

   ```bash
   git add .
   git commit -m "Add your feature"
   ```

5. Push the branch to your fork:

   ```bash
   git push origin feature/new-feature
   ```

6. Open a pull request on the original repository.
