const express = require("express");
const axios = require("axios");
const countryToCurrency = require( 'country-to-currency' );
const app = express();

const PORT = 3000;

app.set("view engine", "ejs");

app.use(express.static("public"));

app.get("/", (req, res) => {
  res.render("index", { weather: null, time: null, currencyConversion: null, error: null });
});

app.get("/weather", async (req, res) => {
  const city = req.query.city;
  const apiKey = "3e363b1c21968ec201efeffd9ada16b3";
  const currencyAPI = "80318e738056c207d9ba"

  let weather;
  let time;
  let currencyConversion;
  let error = null;

  try {
    // Fetch weather using the OpenWeatherMap API
    const weatherAPIUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=imperial&appid=${apiKey}`;
    const weatherResponse = await axios.get(weatherAPIUrl);
    weather = weatherResponse.data;

    // Fetch time using the Time API
    const timeAPIUrl = `https://timeapi.io/api/Time/current/coordinate?latitude=${weather.coord.lat}&longitude=${weather.coord.lon}`;
    const timeResponse = await axios.get(timeAPIUrl);
    time = timeResponse.data;

    // Get the country code using the country-currency library
    currency = countryToCurrency[ weather.sys.country ];
    // Fetch currency conversion using the FreeCurrConv API
    const currencyConversionAPIUrl = `https://free.currconv.com/api/v7/convert?q=USD_${currency}&compact=ultra&apiKey=${currencyAPI}`;
    const currencyConversionRes = await axios.get(currencyConversionAPIUrl);
    const dif = `USD_${currency}`;
    currencyConversion = currencyConversionRes.data[dif] + ` ${currency}`;
  } catch (error) {
    console.error(error);
    weather = null;
    time = null;
    currencyConversion = null;
  }

  res.render("index", { weather, time, currencyConversion, error });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
