const express = require('express');
const mongoose = require('mongoose');

const cookieParser = require('cookie-parser');

const authRoutes = require('./routes/authRoutes');
const { requireAuth, authenticateUser } = require('./middleware/authMidleware');
const User = require('./models/user');

const postRoutes = require('./routes/postRoutes');
const { postMiddleware, getPostByUserId } = require('./middleware/postMidleware');
const Post = require('./models/post');

const PORT = 3000;

require('dotenv').config();

const DBuri = process.env.DBuri;

const adminData = {
    email: 'admin@gmail.com',
    password: process.env.ADMIN_PASSWORD,
    name: 'aspandyar',
    role: 'admin'
};

mongoose.connect(DBuri)
    .then(() => {
        console.log("Connected to DB");
        return User.countDocuments({ role: 'admin' });
    })
    .then(async (adminCount) => {
        if (adminCount === 0) {
            console.log('No admin account found. Creating admin account...');
            await User.createAdmin(adminData);
        } else {
            console.log('Admin account already exists.');
        }
    })
    .catch((err) => console.log(err));

const app = express();

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: false }));
app.use(express.static('public'));
app.use(express.json());
app.use(cookieParser());

app.get('*', authenticateUser);;

app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/monitoring', authenticateUser, (req, res) => {
    res.render('monitoring');
});

app.use(authRoutes);
app.use(postRoutes);

app.listen(PORT, () => {
    console.log(`Server listening on: http://localhost:${PORT}`);
});
