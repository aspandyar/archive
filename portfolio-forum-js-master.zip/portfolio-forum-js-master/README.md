# Portfolio Forum

Welcome to Portfolio Forum! This is a platform where users can create their own portfolios and view portfolios created by others.

## Table of Contents

- [Setup Instructions](#setup-instructions)
- [API Usage Details](#api-usage-details)
- [Key Design Decisions](#key-design-decisions)
- [Author](#author)

## Setup Instructions

To get started with Portfolio Forum, follow these steps:

1. Clone the repository:
   ```bash
   git clone https://github.com/aspandyar/portfolio-forum-js.git
   ```

2. Navigate to the project directory:
   ```bash
   cd portfolio-forum-js
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Configure environment variables:
   Create a `.env` file in the root directory and add the following variables:
   ```plaintext
   JWT_KEY=<your jwt key>
   DBuri=mongodb://localhost:27017
   ADMIN_PASSWORD=<admin password>
   YANDEX_USER=<real yandex user (to mail sender)>
   YANDEX_PASS=<real password of yandex>
   ```

5. Start MongoDB using Docker Compose:
   ```bash
   docker-compose up -d
   ```

6. Start the application:
   ```bash
   npm run start
   ```

Now you should be able to access the Portfolio Forum application at `http://localhost:3000`.

## API Usage Details

The application uses two external APIs to generate random characters for each page:

1. Harry Potter API: [https://hp-api.onrender.com/api/characters](https://hp-api.onrender.com/api/characters)
2. Game of Thrones API: [https://thronesapi.com/api/v2/Characters](https://thronesapi.com/api/v2/Characters)
3. Mail corrections API: [https://www.mailboxvalidator.com/api-email-free](https://www.mailboxvalidator.com/api-email-free)
4. Mail vertification API: [https://www.disify.com](https://www.disify.com)

These APIs are called using the `axios` library. Random characters fetched from these APIs are displayed on various pages of the application to add dynamic content and enhance user experience.

## Key Design Decisions

- **Node.js & Express**: Node.js along with Express framework is chosen for backend development due to its lightweight nature and ability to handle asynchronous operations efficiently.

- **MongoDB**: MongoDB is selected as the database to store user portfolios and other application data. Its flexibility with JSON-like documents makes it suitable for handling various types of data in a portfolio-based application.

- **Frontend Frameworks**: The frontend of the application is built using Bootstrap for styling and layout consistency. Additionally, jQuery is used for DOM manipulation and interaction to enhance user interactivity.

- **External APIs**: Integration with external APIs adds dynamic content to the application, making it more engaging for users. The use of APIs such as Harry Potter and Game of Thrones enhances the user experience by providing diverse and interesting characters for the portfolios.

## Author

- **Aspandyar**
- GitHub: [github.com/aspandyar](https://github.com/aspandyar)
