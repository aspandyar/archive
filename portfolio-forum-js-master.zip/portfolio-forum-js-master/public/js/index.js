function showEditForm() {
    var editSection = document.getElementById("edit-info");
    editSection.style.display = "block";
}

function deletePost() {
    const url = `/`;

    fetch(url, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
        },
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete post');
        }
        window.location.reload();
    })
    .catch(error => {
        console.error('Error deleting post:', error.message);
    });
}


function showEditForm() {
    var editSection = document.getElementById("edit-info");
    editSection.style.display = "block";
}

const editForm = document.getElementById('editForm');
if (editForm) {
    editForm.addEventListener('submit', async function(event) {
        event.preventDefault(); 
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const country = document.getElementById('country').value;
        const city = document.getElementById('city').value;
        const additionalCity = document.getElementById('additionalCity').value;
    
        const res = await fetch('/', {
            method: 'PUT', 
            body: JSON.stringify({ name, email, country, city, additionalCity }),
            headers: {'Content-Type': 'application/json'}
        });
    
        location.assign('/');
    });
}