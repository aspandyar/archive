const form = document.querySelector('form');

const emailError = document.querySelector('.email-error');
const passwordError = document.querySelector('.password-error');

document.getElementById('submit-btn').addEventListener('click', async (e) => {
    e.preventDefault();

    // refresh email, and password error
    emailError.textContent = '';
    passwordError.textContent = '';

    // get values
    const email = form.email.value;
    const password = form.password.value;
    const age = form.age.value;
    const gender = form.gender.value;
    const country = form.country.value;

    try {
        const res = await fetch('/user/signup', {
            method: 'POST', 
            body: JSON.stringify({ email, password, age, gender, country }),
            headers: {'Content-Type': 'application/json'}
        });

        const data = await res.json();

        if (data.errors) {
            emailError.textContent = data.errors.email;
            passwordError.textContent = data.errors.password;
        }

        if (data.user) {
            location.assign('/');
        }
    }
    catch (err) {
        console.log(err);
    }

});

document.getElementById('toggleButton').addEventListener('click', function() {
    var hiddenFields = document.getElementById('hiddenFields');
    if (hiddenFields.classList.contains('hidden')) {
        hiddenFields.classList.remove('hidden');
    } else {
        hiddenFields.classList.add('hidden');
    }
});