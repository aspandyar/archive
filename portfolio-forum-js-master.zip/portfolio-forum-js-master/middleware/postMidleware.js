const jwt = require('jsonwebtoken');
const Post = require('../models/post');

require('dotenv').config();

const jwt_key = process.env.JWT_KEY;

const postMiddleware = async (req, res, next) => {
    const token = req.cookies.jwt;

    if (!token) {
        res.locals.isPresent = false;
        return next();
    }

    
    jwt.verify(token, jwt_key, async (err, decodedToken) => {
        if (err) {
            console.log(err.message);
            res.locals.isPresent = false;
            return next();
        }

        try {
            const post = await Post.findOne({ userId: decodedToken.id });
            if (!post) {
                res.locals.isPresent = false;
            } else {
                res.locals.isPresent = true;
            }
            return next();
        } catch (err) {
            console.error(err.message);
            res.locals.isPresent = false;
            return next();
        }
    });
};

const getPostByUserId = async (req, res, next) => {
    const token = req.cookies.jwt;

    if (!token) {
        res.locals.post = null;
        return next();
    }

    jwt.verify(token, jwt_key, async (err, decodedToken) => {
        if (err) {
            console.log(err.message);
            res.locals.post = null;
            return next();
        }

        try {
            const post = await Post.findOne({ userId: decodedToken.id });
            if (!post) {
                res.locals.post = null;
            } else {
                res.locals.post = post;
            }
            return next();
        } catch (err) {
            console.error(err.message);
            res.locals.post = null;
            return next();
        }
    });
};

module.exports = { postMiddleware, getPostByUserId };
