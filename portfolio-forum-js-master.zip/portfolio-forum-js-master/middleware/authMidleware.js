const jwt = require('jsonwebtoken');
const User = require('../models/user');

require('dotenv').config();

const jwt_key = process.env.JWT_KEY;
const requireAuth = (req, res, next) => {

    const token = req.cookies.jwt;

    if (token) {
        jwt.verify(token, jwt_key, (err, decodedToken) => {
            if (err) {
                console.log(err.message);
                res.redirect('user/login');
            } else {
                console.log(decodedToken);
                next();
            }
        });
    }
    else {
        res.redirect('user/login');
    }
};

const authenticateUser = async (req, res, next) => {
    const token = req.cookies.jwt;

    if (!token) {
        res.locals.user = null;
        res.locals.admin = null;
        return next();
    }

    jwt.verify(token, jwt_key, async (err, decodedToken) => {
        if (err) {
            console.log(err.message);
            res.locals.user = null;
            res.locals.admin = null;
            return next();
        }

        try {
            const user = await User.findById(decodedToken.id);
            if (!user) {
                res.locals.user = null;
            } else {
                res.locals.user = user;
            }

            if (user && user.role === 'admin') {
                res.locals.admin = user;
            } else {
                res.locals.admin = null;
            }

            return next();
        } catch (err) {
            console.error(err.message);
            res.locals.user = null;
            res.locals.admin = null;
            return next();
        }
    });
};

module.exports = { requireAuth, authenticateUser };