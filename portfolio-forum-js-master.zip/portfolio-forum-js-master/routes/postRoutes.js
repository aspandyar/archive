const { Router } = require('express');
const postController = require('../controllers/postController');

const { postMiddleware, getPostByUserId } = require('../middleware/postMidleware');
const { requireAuth, authenticateUser } = require('../middleware/authMidleware');

const router = Router();

router.get('/', postMiddleware, getPostByUserId, postController.portfolio_get);

router.post('/', requireAuth, authenticateUser, postController.portfolio_post);

router.put('/', requireAuth, authenticateUser, postController.portfolio_put);

router.delete('/', requireAuth, authenticateUser, postController.portfolio_delete);

router.get('/portfolio', postController.get_all_posts);

router.get('/motoring', postController.monitoring);

module.exports = router;