const mongoose = require('mongoose');
const { isEmail } = require('validator');

const postSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    pictures: {
        type: [String],
    },
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: [true, 'Please enter an email'],
        lowercase: true,
        validate: [isEmail, 'Please enter a valid email']
    },
    country: {
        type: String,
    },
    city: {
        type: String,
    },
    additionalCity: {
        type: String,
    },
    additionalInfo: {
        type: [String],
    },
    date: {
        type: Date,
        default: Date.now
    }
});

const Post = mongoose.model('Post', postSchema);

module.exports = Post;
