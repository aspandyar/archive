const mongoose = require('mongoose');
const { isEmail } = require('validator');
const bcrypt = require('bcrypt')

// User modele for working with
const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, 'Please enter an email'],
        unique: true,
        lowercase: true,
        validate: [isEmail, 'Please enter a valid email']
    },
    password: {
        type: String,
        required: [true, 'Please enter a password'],
        minLength: [8, 'Minimum password length should be 8 characters']
    },
    name: String,
    age: Number,
    gender: String,
    country: String,
    date: {
        type: Date,
        default: Date.now
    },
    role: {
        type: String,
        default: "user"
    }
});

// prehook of function, which will work before saving user
userSchema.pre('save', async function(next) {
    const salt = await bcrypt.genSalt();

    this.password = await bcrypt.hash(this.password, salt);

    next();
});

// static method for login user
userSchema.statics.login = async function(email, password) {
    const user = await this.findOne({email});

    if (user) {
        const auth = await bcrypt.compare(password, user.password);

        if (auth) {
            return user;
        }
        throw Error('incorrect password');
    }
    throw Error('incorrect email');
};

userSchema.statics.createAdmin = async function(adminData) {
    try {
        const admin = await this.findOne({ email: adminData.email });
        if (!admin) {
            adminData.role = 'admin';
            const newAdmin = new this(adminData);
            await newAdmin.save();
            console.log('Admin account created successfully!');
            return newAdmin;
        } else {
            console.log('Admin account already exists.');
            return admin;
        }
    } catch (error) {
        console.error('Error creating admin account:', error);
        throw error;
    }
};

const User = mongoose.model('user', userSchema);

module.exports = User;