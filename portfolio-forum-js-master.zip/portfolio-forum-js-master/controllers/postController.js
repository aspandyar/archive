const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer'); 
const smtpTransport = require('nodemailer-smtp-transport'); 

require('dotenv').config();

const jwt_key = process.env.JWT_KEY;

const User = require('../models/user');
const Post = require('../models/post');

const statusCreated = 201;
const statusOK = 200;
const statusBadRequest = 400;
const statusInternalServerError = 500;

const transporter = nodemailer.createTransport(smtpTransport({
    service: 'yandex',
    auth: {
      user: process.env.YANDEX_USER,
      pass: process.env.YANDEX_PASS
    }
  }));

module.exports.portfolio_get = (req, res) => {
    res.render('index');
}

module.exports.portfolio_post = async (req, res) => {
    let { name, country, city, additionalCity } = req.body;
    const token = req.cookies.jwt;

    jwt.verify(token, jwt_key, async (err, decodedToken) => {
        if (err) {
            res.locals.errors = err
            res.status(statusInternalServerError).render("errors");
            return;
        }

        let user = await User.findById(decodedToken.id);

        if (!name) {
            name = user.name;
        }

        let email = user.email;

        let result = await fetchCharacterData();
        let characterImageUrl = result.randomCharacters;
        let additionalInfo = result.additionalInfo;

        const mailOptions = {
            from: process.env.YANDEX_USER,
            to: email,
            subject: 'Portfolio Created!',
            html: '<h1>Welcome to Our Website!</h1><p>You successfully craeted your portfolio!</p>'
        };
        
        transporter.sendMail(mailOptions, function(error, info) {
            if (error) {
                console.log('Error occurred: ', error);
            } else {
                console.log('Email sent: ' + info.response);
            }
        });

        try {
            if (name == "") {
                throw new Error("name is empty");
            }

            await Post.create({ userId: user.id, pictures: characterImageUrl, additionalInfo: additionalInfo, name, email, country, city, additionalCity });
            res.redirect('/');
        } catch (err) {
            // console.log(err)
            // const errors = handleErrors(err);
            // res.status(statusBadRequest).json({ errors });
            res.locals.errors = err
            res.status(statusBadRequest).render("errors");
        }
    });
}

const handleErrors = (err) => {
    console.log(err.message, err.code);
    let errors = { email: '', password: '' };

    // incorrect email
    if (err.message == 'incorrect email') {
        errors.email = 'that email is not registered yet';
    }

    if (err.message == 'name is empty') {
        errors.email = 'that email is not registered yet';
    }
    

    if (err.message == 'incorrect password') {
        errors.password = 'that password is incorrect';
    }

    if (err.code == 11000) {
        errors.email = 'that email is already used'
        return errors;
    }


    if (err.message.includes('user validation failed')) {
        Object.values(err.errors).forEach(({ properties }) => {
            errors[properties.path] = properties.message;
        });
    }

    return errors;
}

module.exports.portfolio_put = async (req, res) => {
    const token = req.cookies.jwt;
    const { pictures, name, email, country, city, additionalCity } = req.body;

    jwt.verify(token, jwt_key, async (err, decodedToken) => {
        if (err) {
            res.locals.errors = err
            res.status(statusInternalServerError).render("errors");
            return;
        }

        try {
            const user = await User.findById(decodedToken.id);
            const posts = await Post.find({ userId: user.id });

            if (posts.length !== 1) {
                res.locals.errors = err
                res.status(statusBadRequest).render("errors");
                return;
            }

            const postId = posts[0]._id;


            const updatedPortfolio = {};

            if (pictures) {
                updatedPortfolio.pictures = pictures;
            }
            if (name) {
                updatedPortfolio.name = name;
            } else {
                updatedPortfolio.name = user.name;
            }
            if (email) {
                updatedPortfolio.email = email;
            } else {
                updatedPortfolio.email = user.email;
            }
            if (country) {
                updatedPortfolio.country = country;
            }
            if (city) {
                updatedPortfolio.city = city;
            }
            if (additionalCity) {
                updatedPortfolio.additionalCity = additionalCity;
            }

            await Post.findByIdAndUpdate(postId, updatedPortfolio);

            res.status(statusOK).send('Portfolio updated successfully');
        } catch (err) {
            res.locals.errors = err
            res.status(statusBadRequest).render("errors");
        }
    });
};

module.exports.portfolio_delete = async (req, res) => {
    const token = req.cookies.jwt;

    jwt.verify(token, jwt_key, async (err, decodedToken) => {
        const user = await User.findById(decodedToken.id);
        const posts = await Post.find({ userId: user.id });

        const postId = posts[0]._id;
        if (err) {
            res.locals.errors = err
            res.status(statusInternalServerError).render("errors");
            return;
        }

        try {
            await Post.findByIdAndDelete(postId);
            res.status(statusOK).send('Portfolio deleted successfully');
        } catch (err) {
            res.locals.errors = err
            res.status(statusBadRequest).render("errors");
        }
    });
};

module.exports.get_all_posts = async (req, res) => {
    try {
        const posts = await Post.find();
        console.log(posts);
        res.locals.posts = posts;
        res.render('portfolio');
    } catch (err) {
        res.locals.errors = err;
        res.status(statusInternalServerError).render('errors');
    }
};

module.exports.monitoring = async (req, res) => {
    res.render('monitoring');
}

const axios = require('axios');

async function fetchCharacterData() {
    try {
        const harryPotterResponse = await axios.get('https://hp-api.onrender.com/api/characters');
        const harryPotterCharacters = harryPotterResponse.data.filter(character => character.image);

        const gameOfThronesResponse = await axios.get('https://thronesapi.com/api/v2/Characters');
        const gameOfThronesCharacters = gameOfThronesResponse.data.filter(character => character.imageUrl);

        const seriesQuotesResponse = await axios.get('https://api.seriesquotes.10cyrilc.me/quote');
        const seriesQuotesData = seriesQuotesResponse.data;

        const hp_data = getRandomCharacterImage(harryPotterCharacters);
        const randomHarryPotterImage = hp_data[0];
        const randomHarryPotterName = hp_data[1];

        let randomGameOfThronesCharacter = "https://thronesapi.com/assets/images/" + getRandomCharacterImage(gameOfThronesCharacters);

        const prev_page = '/imgs/image.png';


        if (randomGameOfThronesCharacter.charAt(randomGameOfThronesCharacter.length - 1) === ',') {
            randomGameOfThronesCharacter = randomGameOfThronesCharacter.slice(0, -1);
        }

        const randomCharacters = [prev_page, randomHarryPotterImage, randomGameOfThronesCharacter];

        const randomGameOfThronesFullName = getRandomCharacterFullName(gameOfThronesCharacters);

        const quotes = seriesQuotesData.map(quoteData => quoteData.quote);
        const additionalInfo = [randomHarryPotterName, randomGameOfThronesFullName, quotes[0]];

        return {randomCharacters, additionalInfo};
    } catch (error) {
        console.error('Error fetching data:', error.message);
        return [];
    }
}

function getRandomCharacterImage(characters) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    return [characters[randomIndex].image, characters[randomIndex].name];
}

function getRandomCharacterFullName(characters) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    return characters[randomIndex].fullName;
}
