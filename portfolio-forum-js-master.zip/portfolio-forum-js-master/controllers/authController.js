const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer'); 
const smtpTransport = require('nodemailer-smtp-transport'); 
const axios = require('axios');

require('dotenv').config();

const jwt_key = process.env.JWT_KEY;

const User = require('../models/user');

const statusCreated = 201;
const statusOK = 200;
const statusBadRequest = 400;
const statusInternalServerError = 500;

const transporter = nodemailer.createTransport(smtpTransport({
    service: 'yandex',
    auth: {
      user: process.env.YANDEX_USER,
      pass: process.env.YANDEX_PASS
    }
  }));

// handle errors
const handleErrors = (err) => {
    console.log(err.message, err.code);
    let errors = { email: '', password: '' };

    // incorrect email
    if (err.message == 'incorrect email') {
        errors.email = 'that email is not registered yet';
    }

    if (err.message == 'incorrect password') {
        errors.password = 'that password is incorrect';
    }

    if (err.code == 11000) {
        errors.email = 'that email is already used'
        return errors;
    }


    if (err.message.includes('user validation failed')) {
        Object.values(err.errors).forEach(({ properties }) => {
            errors[properties.path] = properties.message;
        });
    }

    return errors;
}

const maxAge = 30 * 60; // 30 minuts

const createToken = (id) => {
    return jwt.sign({ id }, jwt_key, {
        expiresIn: maxAge
    });
}

module.exports.signup_get = (req, res) => {
    res.render('signup');
}

module.exports.login_get = (req, res) => {
    res.render('login');
}

module.exports.signup_post = async (req, res) => {
    const { email, password, name, age, country, gender } = req.body;

    try {
        const response = await axios.get(`https://www.disify.com/api/email/${email}`);
        const { format, domain, disposable, dns } = response.data;


        if (!format || !dns || disposable) {
        console.log('ATTENTION: This email seems not good');

            if (!format) {
                console.log('Email format is invalid');
            }
            if (!dns) {
                console.log('DNS records do not exist for the domain');
            }
            if (disposable) {
                console.log('Email address is disposable');
            }
        } else {
            console.log('Email is valid');
        }

        const user = await User.create({ email, password, name, age, country, gender });

        const token = createToken(user._id);
        res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });

        const mailOptions = {
            from: process.env.YANDEX_USER,
            to: email,
            subject: 'Welcome to Our Website!',
            html: '<h1>Welcome to Our Website!</h1><p>Thank you for registering on our website. We hope you enjoy your experience!</p>'
        };
        
        transporter.sendMail(mailOptions, function(error, info) {
            if (error) {
                console.log('Error occurred: ', error);
            } else {
                console.log('Email sent: ' + info.response);
            }
        });

        res.status(statusCreated).json({ user: user._id });
    }
    catch (err) {
        const errors = handleErrors(err);
        res.status(statusBadRequest).json({ errors });
    }
}

module.exports.login_post = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.login(email, password);

        const token = createToken(user._id);
        res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });

        res.status(statusOK).json({ user: user._id });
    }
    catch (err) {
        const errors = handleErrors(err);
        res.status(statusBadRequest).json({ errors });
    }
};

module.exports.logout_get = (req, res) => {
    res.cookie('jwt', '', { maxAge: 1 });
    res.redirect('/');
};

module.exports.admin_signup =  async (req, res) => {
    const { email, password, name, age, country, gender } = req.body;

    try {
        const existingAdmin = await User.findOne({ role: 'admin' });
        if (existingAdmin) {
            return res.status(statusForbidden).json({ error: 'Admin account already exists.' });
        }

        const admin = await User.create({ email, password, name, age, country, gender, role: 'admin' });

        res.status(statusCreated).json({ admin: admin._id });
    } catch (err) {
        const errors = handleErrors(err);
        res.status(statusBadRequest).json({ errors });
    }
};

module.exports.admin_login =  async (req, res) => {
    const { email, password } = req.body;

    try {
        const adminUser = await User.findOne({ email, role: 'admin' });
        if (!adminUser) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const match = await bcrypt.compare(password, adminUser.password);
        if (!match) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = createToken(adminUser._id);
        res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });

        res.status(statusOK).json({ user: adminUser._id });
    } catch (error) {
        console.error('Error during admin login:', error);
        res.status(statusInternalServerError).json({ error: 'Internal server error' });
    }
};
