ALTER TABLE users_lists
RENAME COLUMN list_id TO lists_id;