ALTER TABLE users_lists
RENAME COLUMN lists_id TO list_id;