const express = require('express');
const mongoose = require("mongoose");

const blogRouter = require("./route/blogRoute");

const DBuri = "mongodb://root:secret@mongo:27017";
const app = express();

mongoose.connect(DBuri)
    .then(() => app.listen(PORT))
    .catch((err) => console.log(err))
    .then(console.log("Connection to DB successfully"));

app.use(express.json());
app.use("/api/blog", blogRouter);

app.get('/', function(req, res) {
    res.send('Hello World!')
}) 

app.listen(3000, function() {
    console.log('http://localhost:3000/')
})

